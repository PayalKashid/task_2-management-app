from fastapi import APIRouter, Depends, HTTPException
from bson import ObjectId
from datetime import datetime

from database import projects_collection
from schemas.project import ProjectCreate, ProjectUpdate
from models.project import project_helper
from utils.auth import get_current_user

router = APIRouter(prefix="/projects", tags=["Projects"])


# ✅ Create Project
@router.post("")
async def create_project(project: ProjectCreate, user_id: str = Depends(get_current_user)):
    new_project = {
        "name": project.name,
        "description": project.description,
        "user_id": user_id,
        "created_at": datetime.utcnow()
    }

    result = await projects_collection.insert_one(new_project)
    created_project = await projects_collection.find_one({"_id": result.inserted_id})

    return project_helper(created_project)


# ✅ Get All Projects (per user)
@router.get("")
async def get_projects(user_id: str = Depends(get_current_user)):
    projects = []
    cursor = projects_collection.find({"user_id": user_id})

    async for project in cursor:
        projects.append(project_helper(project))

    return projects


# ✅ Get Project by ID
@router.get("/{project_id}")
async def get_project(project_id: str, user_id: str = Depends(get_current_user)):
    project = await projects_collection.find_one({
        "_id": ObjectId(project_id),
        "user_id": user_id
    })

    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    return project_helper(project)


# ✅ Update Project
@router.put("/{project_id}")
async def update_project(project_id: str, project: ProjectUpdate, user_id: str = Depends(get_current_user)):
    update_data = {k: v for k, v in project.dict().items() if v is not None}

    result = await projects_collection.update_one(
        {"_id": ObjectId(project_id), "user_id": user_id},
        {"$set": update_data}
    )

    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")

    updated_project = await projects_collection.find_one({"_id": ObjectId(project_id)})
    return project_helper(updated_project)


# ✅ Delete Project
@router.delete("/{project_id}")
async def delete_project(project_id: str, user_id: str = Depends(get_current_user)):
    result = await projects_collection.delete_one({
        "_id": ObjectId(project_id),
        "user_id": user_id
    })

    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")

    return {"message": "Project deleted successfully"}